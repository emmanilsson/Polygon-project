#include <iostream>

#ifndef VECTOR2F_H
#define VECTOR2F_H



class Vector2f
{
    public:
        float x, y;
};



#endif // !VECTOR2F_H